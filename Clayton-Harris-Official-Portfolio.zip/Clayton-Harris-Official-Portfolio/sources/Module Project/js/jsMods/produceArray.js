export default function displayArray(arrayItem, displayItem){
    displayItem.innerHTML = arrayItem;
}